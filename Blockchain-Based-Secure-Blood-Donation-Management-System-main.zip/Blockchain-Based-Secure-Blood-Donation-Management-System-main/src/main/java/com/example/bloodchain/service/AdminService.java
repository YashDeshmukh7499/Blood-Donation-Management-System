package com.example.bloodchain.service;

public class AdminService {
}
